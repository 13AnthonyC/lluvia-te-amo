
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const hearts = [];
const fontSize = 24;

function randomColor() {
  return `hsl(${Math.random() * 360}, 100%, 70%)`;
}

class Heart {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.text = "te amo";
    this.color = "pink";
    this.speed = Math.random() * 1.2 + 0.3;
  }
  update() {
    this.y += this.speed;
  }
  draw() {
    ctx.fillStyle = this.color;
    ctx.font = fontSize + "px Arial";
    ctx.fillText(this.text, this.x, this.y);
  }
}

function createHeartRain() {
  for (let i = 0; i < 5; i++) {
    let x = Math.random() * canvas.width;
    hearts.push(new Heart(x, 0));
  }
}

function drawFirework(x, y, text) {
  for (let i = 0; i < 80; i++) {
    setTimeout(() => {
      const angle = Math.random() * 2 * Math.PI;
      const radius = Math.random() * 60;
      const fx = x + radius * Math.cos(angle);
      const fy = y + radius * Math.sin(angle);
      ctx.beginPath();
      ctx.fillStyle = randomColor();
      ctx.arc(fx, fy, 2.5, 0, 2 * Math.PI);
      ctx.fill();
    }, i * 5);
  }

  ctx.font = "bold 32px Arial";
  ctx.fillStyle = "white";
  ctx.textAlign = "center";
  ctx.fillText(text, x, y);
}

canvas.addEventListener("click", (e) => {
  drawFirework(e.clientX, e.clientY, "Sofía Cañizales, mi amor");
});

function animate() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.2)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < hearts.length; i++) {
    hearts[i].update();
    hearts[i].draw();
    if (hearts[i].y > canvas.height) {
      hearts.splice(i, 1);
      i--;
    }
  }
  createHeartRain();
  requestAnimationFrame(animate);
}

animate();
